package com.janani.medicalshop.auth;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController {
    @PostMapping("/login")
    public Map<String, String> login(@RequestBody LoginRequest request) {
        // Demo-only endpoint: replace with database-backed authentication and password hashing.
        if (request.email() == null || request.password() == null ||
            request.email().isBlank() || request.password().isBlank()) {
            throw new org.springframework.web.server.ResponseStatusException(
                HttpStatus.BAD_REQUEST, "Email and password are required");
        }
        return Map.of("message", "Demo login endpoint. Configure secure authentication before use.");
    }
    public record LoginRequest(String email, String password) {}
}
