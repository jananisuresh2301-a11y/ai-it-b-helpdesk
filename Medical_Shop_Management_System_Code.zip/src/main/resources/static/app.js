const rows = document.querySelector('#rows');
const message = document.querySelector('#message');
let medicines = [];

async function loadMedicines() {
  try {
    const response = await fetch('/api/medicines');
    if (!response.ok) throw new Error('Could not load medicines');
    medicines = await response.json();
    renderMedicines();
  } catch (error) { message.textContent = error.message; }
}
function renderMedicines() {
  const term = document.querySelector('#search').value.toLowerCase();
  rows.replaceChildren();
  medicines.filter(m => [m.name,m.category,m.manufacturer].some(v => (v || '').toLowerCase().includes(term)))
    .forEach(m => {
      const tr = document.createElement('tr');
      [m.name,m.category,m.manufacturer,m.price,m.stock,m.expiryDate].forEach(value => {
        const td = document.createElement('td'); td.textContent = value ?? '—'; tr.appendChild(td);
      });
      rows.appendChild(tr);
    });
}
document.querySelector('#medicine-form').addEventListener('submit', async event => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.target).entries());
  data.price = data.price ? Number(data.price) : 0;
  data.stock = Number(data.stock);
  if (!data.expiryDate) delete data.expiryDate;
  try {
    const response = await fetch('/api/medicines', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(data)});
    if (!response.ok) { const err = await response.json().catch(()=>({})); throw new Error(err.message || 'Unable to add medicine'); }
    event.target.reset(); message.textContent = 'Medicine added successfully.'; await loadMedicines();
  } catch (error) { message.textContent = error.message; }
});
document.querySelector('#search').addEventListener('input', renderMedicines);
document.querySelector('#refresh').addEventListener('click', loadMedicines);
loadMedicines();
